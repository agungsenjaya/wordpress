jQuery(document).ready(function () {
jQuery("#accordion-section-example_1 .button").click(function(){
  jQuery("#accordion-section-example_1 .button").attr("href", "https://www.sktthemes.org/shop/nightclub-wordpress-theme/");
});
});